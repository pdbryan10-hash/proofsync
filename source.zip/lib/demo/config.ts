/**
 * Demo-mode configuration.
 *
 * The demo models a contractor's job-management system (Joblogic) and a client's
 * CAFM (Concerto) as two genuinely separate databases, and drives ProofSync's
 * real sync engine between them on a fixed beat.
 *
 * Everything here is server-only and inert unless DEMO_MODE=1.
 */

/** Master switch. Every /api/demo/* route and the /demo console 404 without it. */
export function isDemoEnabled(): boolean {
  return process.env.DEMO_MODE === '1';
}

/**
 * Seconds between sync beats. The demo console pings the tick endpoint more
 * often than this; the SERVER decides whether a beat is actually due, so the
 * cadence is a property of the system rather than of whoever has a tab open.
 */
export function getTickSeconds(): number {
  const raw = Number(process.env.DEMO_TICK_SECONDS);
  return Number.isFinite(raw) && raw >= 2 ? raw : 30;
}

/** How many new completed jobs the source system produces per beat (0..max). */
export function getDripPerTick(): number {
  const raw = Number(process.env.DEMO_DRIP_PER_TICK);
  return Number.isFinite(raw) && raw >= 0 ? raw : 3;
}

/**
 * How the connectors reach the two stand-in systems.
 *
 *   direct  — read and write their databases. Fast, robust, runs anywhere.
 *             Models the session lifecycle but does not prove the access method.
 *   browser — drive a real Chromium: fill the login form, read the rendered job
 *             list, type into the target's form, click Save, re-read the page.
 *             This is the real proof for a vendor with no API.
 *
 * IMPORTANT: `browser` CANNOT run on Vercel. There is no Chromium binary in the
 * serverless runtime and the function size limits fight you. It is a local
 * (or containerised worker) transport. A Vercel deployment must stay on `direct`.
 */
export type DemoTransport = 'direct' | 'browser';

/**
 * Runtime transport override (set from the control doc at the start of each beat
 * and each state read, see applyStoredTransport). Lets a presenter flip between
 * the fast direct trickle and the real-browser proof from the UI, no env change.
 * Null = fall back to the DEMO_TRANSPORT env default.
 */
let transportOverride: DemoTransport | null = null;

export function setTransportOverride(t: DemoTransport | null): void {
  transportOverride = t;
}

export function getDemoTransport(): DemoTransport {
  if (transportOverride) return transportOverride;
  return process.env.DEMO_TRANSPORT === 'browser' ? 'browser' : 'direct';
}

export function isBrowserTransport(): boolean {
  return getDemoTransport() === 'browser';
}

/**
 * Where the stand-in systems' own web UIs are served from. The browser transport
 * points Chromium at these, so it must be an address the machine running the
 * browser can actually reach.
 */
export function getDemoBaseUrl(): string {
  return process.env.DEMO_BASE_URL || 'http://localhost:3000';
}

/**
 * Remote-browser (Browserbase) config. When present, the browser transport
 * connects to a hosted Chromium over CDP instead of launching a local one — so
 * the "log in like a person" transport runs on serverless / anywhere, not just a
 * machine with Chromium installed. Absent → fall back to a local Playwright
 * launch (dev). Requires DEMO_BASE_URL to be a public URL the remote browser can
 * reach (e.g. https://www.proofsync.co.uk), not localhost.
 *
 * Only the API KEY is required: modern Browserbase resolves the project from the
 * key itself, so BROWSERBASE_PROJECT_ID is optional. If it isn't set, the browser
 * connector resolves a project id from the key at launch (GET /v1/projects) — the
 * user never has to find or paste one.
 */
export function getBrowserbaseConfig(): { apiKey: string; projectId: string | null } | null {
  const apiKey = process.env.BROWSERBASE_API_KEY;
  if (!apiKey) return null;
  return { apiKey, projectId: process.env.BROWSERBASE_PROJECT_ID || null };
}

export function isRemoteBrowser(): boolean {
  return getBrowserbaseConfig() !== null;
}

/**
 * Show the browser window. Headed is the point of a live demo — a prospect
 * watching Chromium type into the client's system is the whole argument. Set
 * DEMO_HEADLESS=1 to run it invisibly (the screenshots still land in the ledger).
 */
export function isHeadedBrowser(): boolean {
  return process.env.DEMO_HEADLESS !== '1';
}

/**
 * Driving a browser costs roughly 10–20s per job against ~4.5s for a direct
 * write, so a beat has to attempt far fewer of them or the route's 60s budget
 * is gone. Overflow stays PENDING for the next beat.
 */
export function getMaxDispatchesPerTick(): number {
  const raw = Number(process.env.DEMO_MAX_SYNCS_PER_TICK);
  if (Number.isFinite(raw) && raw > 0) return raw;
  // Deliberately a slow trickle in direct mode: syncing the whole batch in one
  // or two beats reads as "everything succeeded at once". A few per beat lets a
  // viewer watch the Joblogic jobs cross into Concerto one cluster at a time.
  //
  // Browser mode drives ONE job per beat. A browser-driven sync (Browserbase
  // connect + login + fill + save + verify) is ~20-30s; two of them plus the
  // route's overhead overran the 60s function limit, so beats were killed before
  // recording the run or its screenshots — which is why the evidence filmstrip
  // stayed empty and the demo "showed just cards". One per beat finishes well
  // inside budget and captures its screenshots every time.
  return isBrowserTransport() ? 1 : 3;
}

/**
 * Run a beat's direct syncs CONCURRENTLY rather than one at a time.
 *
 * Off by default and gated: on the free M0 cluster, concurrent syncs exhausted
 * the tiny connection pool and produced zero completions, so the demo has always
 * dispatched sequentially. On a dedicated cluster (M10+) that limit is gone, and
 * running the batch in parallel is what makes Act 2 actually "hum" — every job
 * crossing at once instead of trickling. Flip DEMO_CONCURRENT_SYNC=1 only when
 * the demo is on a cluster that can take it.
 */
export function isConcurrentSync(): boolean {
  return process.env.DEMO_CONCURRENT_SYNC === '1';
}

/**
 * Swap the database name on a Mongo connection string, preserving credentials
 * and options verbatim.
 *
 * Deliberately string-surgery rather than `new URL()`: round-tripping through
 * URL re-encodes the userinfo, which corrupts passwords containing reserved
 * characters. A valid connection string already has those percent-encoded, so
 * the host section can be located by the first '/' after the scheme.
 */
export function withDatabaseName(uri: string, dbName: string): string {
  const queryAt = uri.indexOf('?');
  const beforeQuery = queryAt === -1 ? uri : uri.slice(0, queryAt);
  const query = queryAt === -1 ? '' : uri.slice(queryAt);

  const schemeEnd = beforeQuery.indexOf('://');
  if (schemeEnd === -1) {
    throw new Error('DATABASE_URL is not a valid Mongo connection string.');
  }
  const hostStart = schemeEnd + 3;
  const pathSlash = beforeQuery.indexOf('/', hostStart);
  const base = pathSlash === -1 ? beforeQuery : beforeQuery.slice(0, pathSlash);

  return `${base}/${dbName}${query}`;
}

function requireBaseUri(): string {
  const uri = process.env.DATABASE_URL;
  if (!uri) throw new Error('DATABASE_URL is not set — demo mode cannot connect.');
  return uri;
}

/**
 * Connection string for the SOURCE system's database (Joblogic stand-in).
 * Defaults to a separate database on the same cluster as ProofSync, so the demo
 * needs no extra infrastructure. Override to put it on its own cluster entirely.
 */
export function getSourceDbUri(): string {
  return (
    process.env.DEMO_JOBLOGIC_DB_URL ||
    withDatabaseName(requireBaseUri(), getSourceDbName())
  );
}

/** Connection string for the TARGET system's database (Concerto stand-in). */
export function getTargetDbUri(): string {
  return (
    process.env.DEMO_CONCERTO_DB_URL ||
    withDatabaseName(requireBaseUri(), getTargetDbName())
  );
}

export function getSourceDbName(): string {
  return process.env.DEMO_JOBLOGIC_DB_NAME || 'proofsync_demo_joblogic';
}

export function getTargetDbName(): string {
  return process.env.DEMO_CONCERTO_DB_NAME || 'proofsync_demo_concerto';
}

/**
 * Credentials the simulated connectors "log in" with. These are the demo
 * systems' OWN fake logins — they guard nothing real and are seeded into each
 * demo database. They exist to model the session lifecycle (authenticate →
 * session token → expiry → re-authenticate), not to provide security.
 */
export const DEMO_SOURCE_LOGIN = {
  username: 'proofsync.integration@meridian-fm.example',
  password: 'demo-not-a-real-secret',
};

export const DEMO_TARGET_LOGIN = {
  username: 'proofsync.svc@concerto-client.example',
  password: 'demo-not-a-real-secret',
};

/** Simulated session lifetime, so the demo exercises a re-login mid-run. */
export const DEMO_SESSION_TTL_MS = 5 * 60_000;

/**
 * The demo runs inside its own Organisation so it can be reset without touching
 * the seeded product-tour data that /dashboard and /jobs render.
 */
// NOTE: bumped to a fresh org so the ledger starts clean. An earlier concurrency
// bug left orphaned rows under the previous org that Prisma's relation checks
// couldn't delete; a new org name sidesteps that data entirely rather than
// trying to repair it. The old org's rows are harmless and simply unused.
export const DEMO_ORG_NAME = 'Meridian FM — live sync demo (v2)';
export const DEMO_CLIENT_NAME = 'Northgate Retail Estates';
export const DEMO_CONCERTO_TENANT = 'northgate-concerto';
